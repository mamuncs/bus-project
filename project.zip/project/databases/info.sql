-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2022 at 06:43 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `info`
--

-- --------------------------------------------------------

--
-- Table structure for table `area_info`
--

CREATE TABLE `area_info` (
  `id` int(11) NOT NULL,
  `start` varchar(255) NOT NULL,
  `end` varchar(255) NOT NULL,
  `distance` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  `busname` varchar(255) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `startjourneytime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area_info`
--

INSERT INTO `area_info` (`id`, `start`, `end`, `distance`, `cost`, `busname`, `time`, `startjourneytime`) VALUES
(1, 'Dhaka', 'Khulna', '550km', '700tk', 'Sohag', '8 hours', '5:15 PM'),
(2, 'Dhaka', 'Narail', '450km', '500tk', 'Digonto', '8 hours', '3.10 PM'),
(3, 'Dhaka', 'Barisal', '550km', '700tk', 'BM poribohon', '8 hours', '1.45 PM'),
(4, 'Dhaka', 'Rangpur', '550km', '700tk', 'Ran poribohon', '8 hours', '2.50 PM'),
(5, 'Dhaka', 'Chottogram', '600km', '800tk', 'Snigdha', '10 hours', '4.15 pM'),
(7, 'Dhaka', 'Dinajpur', '610km', '630tk', 'Korotoa', '5.2 hours', '7.45 PM'),
(10, 'Dhaka', 'Cummilla', '90km', '360tk', 'Km spiceal', '4.20 hours', '8.15 PM'),
(11, 'Dhaka', 'Shylet', '610km', '690tk', 'Shajalal', '7 hours', '9.45 PM'),
(12, 'Dhaka', 'Gazipur', '60km', '80tk', 'Gazipur Bohon', '2 hours', '1.15 PM');

-- --------------------------------------------------------

--
-- Table structure for table `privacy_policy`
--

CREATE TABLE `privacy_policy` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `testuser`
--

CREATE TABLE `testuser` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testuser`
--

INSERT INTO `testuser` (`id`, `email`, `pass`) VALUES
(1, 'mamun@gmail.com', '1234'),
(2, 'mamun@gmail.com', '1234'),
(3, 'test@gmail.com', 'test'),
(4, 'fadf', 'sdaff'),
(5, 'fffff@gmail.com', 'passsss'),
(8, 'fffff@gmail.com', 'passsss');

-- --------------------------------------------------------

--
-- Table structure for table `ticketinfo`
--

CREATE TABLE `ticketinfo` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `start` varchar(200) NOT NULL,
  `end` varchar(200) NOT NULL,
  `busname` varchar(200) NOT NULL,
  `distance` varchar(200) NOT NULL,
  `cost` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL DEFAULT 'Paid',
  `currentime` timestamp NOT NULL DEFAULT current_timestamp(),
  `ticketday` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticketinfo`
--

INSERT INTO `ticketinfo` (`id`, `fname`, `lname`, `phone`, `email`, `gender`, `start`, `end`, `busname`, `distance`, `cost`, `time`, `status`, `currentime`, `ticketday`) VALUES
(5, 'Abdur', 'Rahman', '12333333', 'ab@gmail.com', 'Male', 'Dhaka', 'Gazipur', 'Gazipur Bohon', '60km', '80tk', '2 hours', 'Paid', '2022-02-16 23:14:41', '2023-02-17 02:15:00'),
(37, 'Al-Mamun', 'Molla', '01778631100', 'm@gmail.com', 'Male', 'Dhaka', 'Gazipur', 'Gazipur Bohon', '60km', '80tk', '2 hours', 'Paid', '2022-02-19 16:30:57', '2022-02-20 01:15:00'),
(45, 'Arohi', 'Sultana', '0111245522', 'a@gmail.com', 'FeMale', 'Dhaka', 'Gazipur', 'Gazipur Bohon', '60km', '80tk', '2 hours', 'Paid', '2022-02-20 00:24:57', '2022-02-20 01:15:00'),
(46, 'Arohi', 'Sultana', '0111245522', 'a@gmail.com', 'FeMale', 'Dhaka', 'Khulna', 'Sohag', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 01:28:07', '2022-02-19 05:15:00'),
(47, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Khulna', 'Sohag', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 09:35:13', '2022-02-21 05:15:00'),
(48, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Shylet', 'Shajalal', '610km', '690tk', '7 hours', 'Paid', '2022-02-20 14:10:54', '2022-02-20 09:45:00'),
(49, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Shylet', 'Shajalal', '610km', '690tk', '7 hours', 'Paid', '2022-02-20 14:11:12', '2022-02-20 09:45:00'),
(50, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Shylet', 'Shajalal', '610km', '690tk', '7 hours', 'Paid', '2022-02-20 14:11:26', '2022-02-20 09:45:00'),
(51, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Rangpur', 'Ran poribohon', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 14:32:55', '2022-02-20 02:50:00'),
(52, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Rangpur', 'Ran poribohon', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 14:33:17', '2022-02-20 02:50:00'),
(53, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Rangpur', 'Ran poribohon', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 14:33:40', '2022-02-20 02:50:00'),
(54, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Khulna', 'Sohag', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 16:33:10', '2022-02-20 05:15:00'),
(55, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Khulna', 'Sohag', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 16:33:28', '2022-02-20 05:15:00'),
(56, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Khulna', 'Sohag', '550km', '700tk', '8 hours', 'Paid', '2022-02-20 16:33:41', '2022-02-20 05:15:00'),
(57, 'Mamun', 'last', '000000', 'test@gmail.com', 'Male', 'Dhaka', 'Gazipur', 'Gazipur Bohon', '60km', '80tk', '2 hours', 'Paid', '2022-02-21 13:11:49', '2022-02-15 01:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `usr_pwd` varchar(255) NOT NULL,
  `con_usr_pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `email`, `phone`, `gender`, `usr_pwd`, `con_usr_pwd`) VALUES
(66, 'Al-Mamun', 'Molla', 'm@gmail.com', '01778631100', 'Male', '1111', '1111'),
(67, 'Arohi', 'Sultana', 'a@gmail.com', '0111245522', 'FeMale', '1234', '1234'),
(68, 'Mamun', 'khan', 'test@gmail.com', '000000', 'Male', '1234', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area_info`
--
ALTER TABLE `area_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testuser`
--
ALTER TABLE `testuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticketinfo`
--
ALTER TABLE `ticketinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area_info`
--
ALTER TABLE `area_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `privacy_policy`
--
ALTER TABLE `privacy_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testuser`
--
ALTER TABLE `testuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ticketinfo`
--
ALTER TABLE `ticketinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
